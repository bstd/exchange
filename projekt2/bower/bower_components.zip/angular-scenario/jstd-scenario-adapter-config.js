/**
 * Configuration for jstd scenario adapter 
 */
var jstdScenarioAdapter = {
  relativeUrlPrefix: '/build/docs/'
};
