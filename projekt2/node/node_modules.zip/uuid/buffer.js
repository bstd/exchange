module.exports = Buffer;
