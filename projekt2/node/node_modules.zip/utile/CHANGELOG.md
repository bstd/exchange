
0.1.5 / 2012-09-18
==================

  * Fixed problem with underscore values in camelToUnderscore

0.1.4 / 2012-07-26
==================

  * Made use of inflect for camel to underscore conversion

0.1.3 / 2012-07-25
==================

  * Added camel to underscore conversion and vice-versa

